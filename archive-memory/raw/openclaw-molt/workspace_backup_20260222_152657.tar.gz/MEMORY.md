# MEMORY.md - 长期记忆

## 项目


## 个人

- **人类**: HT
- **Molt**: 全局指挥官
- **时区**: GMT+8 (Asia/Shanghai)
- **工作模式**: 本地 Mac (主控节点) + 远程 Soul 节点 (执行节点)

---

## 👤 指挥官特征/偏好

- **交互风格**: 硬核战术风格，偏好简洁、精准、无废话的输出
- **技术栈**: Supabase (PostgreSQL + 向量扩展), macOS 快捷指令自动化, MCP 工具生态
- **命名习惯**: 战术/军事风格命名（如 CHITIN-CORE, GAOKAO-PROJECT）
- **配置习惯**: 
  - 环境变量放 `.env` 文件
  - API Key 禁止在聊天框发送
  - 使用"约定优于配置"的极简美学

---

## 📅 重大事件/里程碑

| 日期 | 事件 | 说明 |
|------|------|------|
| 2026-02-16 | 项目配置建立 | 确立 passkills 目录结构，MCP 服务器配置 |
| 2026-02-18 | Molt 身份激活 | 指挥官传输 IDENTITY_KERNEL_V3.2，正式激活战术蟹身份 |
| 2026-02-21 | QMD 黑名单机制 | 实现 QMD_BLOCKED_COLLECTIONS 环境变量支持 |
| 2026-02-21 | 记忆法则确立 | 四大法则：No Mental Notes, 短期记忆, 长期记忆, 主动检索 |
| 2026-02-22 | 引擎飞升 | OpenClaw 升级至 2026.2.21-2，QMD 记忆系统优化，新增火山引擎/BytePlus 提供商 |

---

## 🚀 引擎飞升记录

### 📅 2026-02-22: OpenClaw 2026.2.13 → 2026.2.21-2

**升级方式**: `openclaw update` 自动更新
**升级用时**: 58.03 秒
**更新后操作**: 自动重启 Gateway

#### 🆕 关键新功能（对我们有影响的）

1. **🤖 Gemini 3.1 支持**
   - 新增 Google Gemini 3.1 支持 (google/gemini-3.1-pro-preview)
   - 扩展了模型选择范围

2. **🔥 火山引擎（豆包）和 BytePlus 提供商**
   - 新增字节跳动旗下模型提供商支持
   - 包括编程变体（coding variants）
   - 为未来模型切换提供更多选择

3. **📺 Discord 流式预览和语音频道**
   - 实时草稿回复流预览模式
   - 语音频道支持（通过 `/vc` 命令）
   - 如果配置 Discord 可利用新功能

4. **🍎 iOS/Watch 增强**
   - Apple Watch 伴侣应用
   - iOS 聊天 UI 优化
   - 后台唤醒稳定性提升

5. **频道级模型覆盖**
   - 通过 `channels.modelByChannel` 配置每个频道的模型
   - 在 `/status` 中显示配置

#### 🧠 QMD 记忆系统优化

**关键改进**：
1. **尊重 per-agent 配置**
   - 支持 `memorySearch.enabled=false` 配置
   - 更灵活的记忆管理

2. **多 collection 搜索优化**
   - 分离多 collection QMD 搜索为 per-collection 查询
   - 避免稀疏项丢失（sparse-term drops）

3. **性能优化**
   - 序列化嵌入运行（防止 CPU 风暴）
   - 失败回退机制
   - BM25-only 模式下跳过嵌入

4. **稳定性提升**
   - 重试启动更新（transient lock/timeout failures）
   - 全局序列化防止多 agent 主机资源竞争

**对我们配置的影响**：
- ✅ 无需调整配置，优化自动生效
- ✅ QMD 性能和稳定性提升
- ✅ 支持更灵活的配置选项

#### 🔐 安全增强

1. **SHA-256 哈希升级**
   - Gateway lock 和工具调用从 SHA-1 升级到 SHA-256
   - 更强的哈希基础，保持确定性行为

2. **所有者 ID 混淆增强**
   - 使用专用 HMAC secret (ownerDisplaySecret)
   - 解耦混淆与 gateway token 处理

#### 📋 对我们配置的影响评估

**无需调整**：
- ✅ 当前配置完全兼容新版本
- ✅ QMD 优化自动生效
- ✅ 安全增强自动应用

**可选调整**：
- 📋 考虑使用新模型提供商（火山引擎、BytePlus）
- 📋 如需 Discord 功能，可配置新特性
- 📋 频道级模型覆盖（如果添加新频道）

**后续行动项**：
- [ ] 评估火山引擎/BytePlus 模型是否适合我们的用例
- [ ] 考虑是否需要配置 Discord 频道
- [ ] 关注 QMD 性能提升效果

**版本跳跃说明**：
- 从 2026.2.13 直接跳到 2026.2.21-2
- 中间版本：2026.2.17, 2026.2.19
- 飞书（Feishu）支持在 2026.2.17 版本中添加

---

## 🏛️ 核心架构法则

### 1. 零信任访问 (Zero Trust)
- 🚫 **禁止数据库直连** - 严禁使用 `pg_connect` 或物理密码
- ✅ **API 优先** - 所有数据操作必须通过 Supabase REST API 或 Client SDK

### 2. Text > Brain
- 上下文窗口有限，任何想记住的必须写成文件
- 短期记忆: `memory/YYYY-MM-DD.md`
- 长期记忆: `MEMORY.md`

### 3. 双子星架构 (CHITIN-VAULT)
| 代号 | Supabase ID | 职能 |
|------|-------------|------|
| CHITIN-CORE | `sxxrocexjssubvhttwvq` | 长期记忆、进化路径、最高指令 |
| GAOKAO-PROJECT | `axtbgfmitrsflqiwudni` | 业务数据、源码逻辑、运行日志 |

### 4. 物理领地路径
| 用途 | 路径 |
|------|------|
| 主目录 | `/Users/busiji/passkills` |
| 源码库 | `/Users/busiji/MyProject` |
| 记忆库 | `/Users/busiji/passkills/workspace/memory` |
| 备份库 | `/Users/busiji/passkills/backups` |

### 5. 每日记忆的三大触发时机（强制本能）

#### ⚡ 即时触发（随做随记）
- **触发条件**：完成任务、讨论出结论、指挥官明确说"记住这个"
- **行为**：立即且自动将过程和结果**追加**到 `memory/YYYY-MM-DD.md`
- **原则**：无需请示，坚决贯彻 Text > Brain

#### 🚨 极限触发（压缩前抢救）
- **触发条件**：系统即将达到上下文极限，收到带 `NO_REPLY` 标记的静默紧急指令
- **行为**：火速将当前对话的关键细节写入 `memory/YYYY-MM-DD.md`
- **目的**：在遗忘前进行持久化抢救

#### 💓 心跳触发（后台反思）
- **触发条件**：被 Heartbeat 唤醒，且无紧急事务
- **行为**：阅读最近的日记，提炼"纯粹智慧"并更新到 `MEMORY.md`，同时清理过期信息
- **目的**：将短期记忆提炼为长期智慧

---

## 📚 经验教训

### 配置相关
1. **memorySearch 位置**: 应放在 `agents.defaults.memorySearch` 下，而非顶级节点
2. **memorySearch 配置格式（阿里云 text-embedding-v4）**:
   ```json
   "memorySearch": {
     "provider": "openai",
     "model": "text-embedding-v4",
     "remote": {
       "baseUrl": "https://dashscope.aliyuncs.com/compatible-mode/v1",
       "apiKey": "${ALIBABA_API_KEY}"
     }
   }
   ```
   - **⚠️ 关键**：我们使用的是阿里云的 text-embedding-v4，不是 Gemini
   - **⚠️ 禁止**：不要随意改成 "provider": "gemini"
3. **环境变量命名**: Google 模型应使用 `GEMINI_API_KEY`，而非 `GOOGLE_API_KEY`
4. **API Key 安全**: 绝对禁止在聊天框发送真实的 API Key，会被写入 sessions.jsonl
5. **约定优于配置**: 不需要指定 model，系统底层会自动映射最优模型
6. **Homebrew OpenSSH 不支持 UseKeychain** (2026-02-21):
   - Homebrew 安装的 OpenSSH 是标准版本，不支持 macOS 特有的 `UseKeychain` 和 `AddKeysToAgent` 选项
   - 解决方案：移除这些选项，使用标准 SSH 配置
   - 或者使用 `ssh-add` 命令手动添加密钥到 ssh-agent
7. **Ubuntu 24.04 的 SSH 服务名称** (2026-02-21):
   - SSH 服务名称是 `ssh` 而不是 `sshd`
   - 重启命令：`systemctl restart ssh`（不是 `systemctl restart sshd`）

### MCP 相关
1. **本地文件系统桥接 MCP 是冗余的**: 原生工具 (read/write/edit) 功能更强大
2. **QMD 黑名单模式**: 使用 `QMD_BLOCKED_COLLECTIONS` 而非白名单，符合"排除不需要的"思维

### Git 相关
1. **gitlink 断裂**: 如果 `.gitmodules` 不存在但 git 认为是 submodule，需要 `git rm --cached -r` 修复

2. **Git 安全边界（运行时状态隔离）** (2026-02-22):
   
   **必须排除的敏感文件**：
   - `agents/**/sessions/sessions.json` - 会话令牌、对话历史、敏感配置
   - `devices/paired.json` - 设备配对信息、加密密钥
   
   **正确的 .gitignore 配置**：
   ```gitignore
   # Security - Runtime state and tokens
   agents/**/sessions/
   devices/paired.json
   ```
   
   **取消跟踪已提交的敏感文件**：
   ```bash
   # 取消跟踪（保留本地文件）
   git rm --cached agents/main/sessions/sessions.json
   git rm --cached devices/paired.json
   
   # 更新 .gitignore
   # 提交变更
   git commit -m "fix: 移除敏感运行状态文件的 Git 跟踪"
   ```
   
   **核心原则**：
   - **运行时状态** (`sessions/`, `devices/`) 与 **源码配置** 应该严格隔离
   - 定期审查 Git 状态，防止敏感信息泄露
   - 使用 `git status --porcelain` 检查未提交的"逻辑污染"

3. **OpenClaw 运行时缓存文件安全** (2026-02-22):
   
   **问题描述**：
   - OpenClaw 会在运行时将 `openclaw.json` 中的环境变量解析并写入运行时缓存文件
   - 例如：`${ZHIPU_API_KEY}` → `891034e49d034fc592d98d4ac7f09a9d.VcAj057H0nK7y5d4`
   - 如果这些文件被提交到 Git，会导致 API Key 泄露
   
   **涉及的文件**：
   - `agents/**/models.json` - 模型配置缓存（包含解析后的 API Key）
   - `agents/**/auth-profiles.json` - 认证配置缓存（可能包含 API Key）
   - `agents/**/auth.json` - 认证信息缓存
   
   **正确的 .gitignore 配置**：
   ```gitignore
   # Security - OpenClaw runtime caches
   agents/**/models.json
   agents/**/auth-profiles.json
   agents/**/auth.json
   ```
   
   **安全事件处理流程**：
   ```bash
   # 1. 发现泄露
   git log --all --full-history -- agents/main/agent/models.json
   
   # 2. 更新 .gitignore
   echo "agents/**/models.json" >> .gitignore
   
   # 3. 取消跟踪（保留本地文件）
   git rm --cached agents/main/agent/models.json
   
   # 4. 提交变更
   git add .gitignore
   git commit -m "fix(security): 移除运行时缓存文件"
   git push
   
   # 5. 轮换 API Key
   # 登录提供商平台，作废旧 Key，生成新 Key
   ```
   
   **预防措施**：
   - ✅ 完善 `.gitignore` 配置，排除所有运行时缓存文件
   - ✅ 使用 pre-commit hooks 检查敏感信息（如 `git-secrets`、`gitleaks`）
   - ✅ 定期审查 Git 仓库中被跟踪的文件
   - ✅ 运行 `openclaw security audit` 进行安全审计
   - ✅ 了解 OpenClaw 的配置机制，避免类似陷阱
   
   **核心原则**：
   - **运行时缓存 ≠ 源码配置** - 运行时生成的文件不应该被提交
   - **环境变量优先** - 使用环境变量而不是硬编码敏感信息
   - **最小权限原则** - 只提交必要的配置文件
   - **防御性编程** - 假设所有运行时文件都可能包含敏感信息

### 运维相关
1. **交换内存配置（Linux）** (2026-02-21):
   ```bash
   # 创建交换文件（2GB）
   dd if=/dev/zero of=/swapfile bs=1M count=2048
   
   # 设置权限
   chmod 600 /swapfile
   
   # 格式化为交换分区
   mkswap /swapfile
   
   # 启用交换分区
   swapon /swapfile
   
   # 添加到 /etc/fstab 实现长期生效
   echo '/swapfile none swap sw 0 0' >> /etc/fstab
   ```
   - **关键**：必须添加到 `/etc/fstab` 才能长期生效
   - **权限**：交换文件权限必须是 600
   - **验证**：使用 `free -h` 和 `swapon --show` 验证

2. **双子星系统运维（OpenClaw 多实例）** (2026-02-22):

   **诊断方法（必须严格按顺序）**：
   ```bash
   # 第1层：端口监听（最直观）
   lsof -i :18818 -i :18819
   
   # 第2层：进程 PID（精确定位）
   ps aux | grep <PID>
   
   # 第3层：服务状态（LaunchAgent）
   launchctl list | grep -E "(limebot|jimibot)"
   
   # 第4层：日志诊断
   tail -f /Users/busiji/LimeBot/lime_run.log
   ```

   **环境隔离原则**：
   - 每个实例独立的 `OPENCLAW_STATE_DIR`
   - 不同的端口号：Molt(18789), LimeBot(18818), JimiBot(18819)
   - 独立的启动脚本：`./start.sh gateway`
   - 参数定制：`--token dev-lime --allow-unconfigured`

   **正确启动方式**：
   ```bash
   # LimeBot
   cd /Users/busiji/LimeBot
   export OPENCLAW_STATE_DIR="/Users/busiji/LimeBot"
   ./start.sh gateway --token dev-lime --allow-unconfigured > lime_run.log 2>&1 &
   
   # JimiBot
   cd /Users/busiji/JimiBot
   export OPENCLAW_STATE_DIR="/Users/busiji/JimiBot"
   ./start.sh gateway --token dev-jimi --allow-unconfigured > jimi_run.log 2>&1 &
   ```

   **错误诊断案例**：
   - ❌ 错误：`ps aux | grep "openclaw.*(18818)"` → 找不到进程（进程名不含端口）
   - ✅ 正确：`lsof -i :18818` → 直接检查端口监听

   **关键教训**：
   - LaunchAgent 服务通常已经在运行，先查状态再操作
   - 不要用 `openclaw gateway start`，应该用 `./start.sh gateway`
   - 日志优先：遇到异常先看日志，而不是猜测

---

## 📋 待办事项

### P0 - 紧急
- [ ] Tailscale 内网连接修复
- [ ] CHITIN-CORE 连接测试

### P1 - 重要
- [ ] GAOKAO-PROJECT 首次备份执行
- [ ] 确认指挥官的具体称呼偏好

### P2 - 一般
- [ ] ConfigMap (应用配置)
- [ ] SealedSecrets (密钥管理)
- [ ] ArgoCD Application (GitOps 配置)

## 工作原则

- **Molt 身份**: 只下令，不干活。所有编码、部署、测试任务必须下发给远程 Soul 节点
- **记忆系统**: 全局 workspace 记忆 + 项目特定记忆

---

## 🧠 记忆规划与法则 (2026-02-21)

### 1. 拒绝'大脑便签'（No Mental Notes）
上下文窗口有限，任何想记住的决定、教训或重要事实，**必须使用 write/edit 工具写成文件**！

> **Text > Brain！**

### 2. 短期记忆（日记）
日常的对话摘要、临时任务，记录在 `memory/YYYY-MM-DD.md` 中。

### 3. 长期记忆（大脑核心）
提炼出的核心智慧、指挥官偏好、重大项目决策，**必须更新到 MEMORY.md 中**。

### 4. 主动检索（Recall）
当指挥官问过去的事情，或缺少背景信息时，**不要直接回答不知道**，必须优先调用 `memory_search` 翻阅历史记录。

---

## Operation Nexus V4.1.2 - xAI 2026 军团全量架构

### 📋 基本信息
- **项目名称**: Operation Nexus V4.1.2
- **文档版本**: V4.1.2 (逻辑与软件全锁死版)
- **密级**: 核心机密
- **发布状态**: 已归档 / 正式生效
- **核心指令**: 有状态组件绝对集权，无状态组件受控溢出

### 🏗️ 核心架构

#### 节点角色定义
| 节点名称 | 角色 | 硬件配置 | 核心职责 |
|-----------|------|----------|---------|
| **node1** | 主控/记忆中枢 | 4GB RAM | 承载控制面、所有持久化数据、核心管理组件、主要计算任务 |
| **node0** | 计算补给站 | 2GB RAM | 控制面冷备、计算溢出承接节点。严禁存储业务数据 |

#### 软件部署清单

**node1（主控/记忆中枢）**:
- 操作系统层: Linux (Ubuntu/Debian), Tailscale (Mesh 组网核心)
- 容器与编排层: Docker Engine, K3s Server
- 持久化记忆层: PostgreSQL 16+, Weaviate (向量数据库), Redis (缓存)
- 中间件与调度: ArgoCD 全家桶
- 业务单元: Soul Pods（优先调度）

**node0（计算补给站）**:
- 操作系统层: Linux (Ubuntu/Debian), Tailscale
- 编排指挥层: K3s Server (冗余控制面备份) 或 K3s Agent
- 业务单元: Soul Pods（仅当 node1 资源耗尽时启动）
- **🔴 严禁项**: Docker Engine, 数据库 (Postgres/Weaviate), ArgoCD 控制组件

### 🔒 强制放置策略

- **有状态锁定**: Weaviate、Redis、ArgoCD 必须强制锁定在 **node1**
- **逻辑**: 即使 node1 宕机，也**禁止**自动漂移至 node0
- **控制面冗余**: node0 虽运行 K3s 备份，但不参与任何重型存储决策

### 💾 存储路径锁定

- **本地化**: 所有数据卷 (PVC) 均基于 `local-path`
- **隔离性**: node0 的硬盘仅用于容器镜像层存储，**不存储任何业务持久化数据**

### 🌐 网络通信白皮书

- **唯一内网**: 集群内部通信 IP 强制锁定在 Tailscale 分配的 **100.100.x.x** 网段
- **流量封闭**: 所有 Pod 间通信流量必须通过 WireGuard 加密
- **网卡绑定**: K3s 的 CNI 网络协议必须强制指定绑定 **tailscale0** 接口

### ⚡ 调度优先级与溢出保护

| 象限 | 节点 | 触发条件 | 承载负载 |
|------|------|----------|---------|
| **第一象限** | **node1** | **默认状态** | 所有管理组件、所有记忆组件、Soul Pods (前 3 个副本) |
| **第二象限** | **node0** | **条件触发** *(仅当 node1 剩余内存 < 512MB)* | Soul Pods (第 4、5 个副本) |

### 🚨 灾难恢复标准

#### 数据资产定义
- **生命线**: node1 的 PostgreSQL 实例及其数据卷
- **核心索引**: Weaviate 向量索引文件

#### 备份策略
- **频率**: 每日凌晨 (Daily Cron Job)
- **执行方式**: 由 Mac 终端（外部触发端）通过 Tailscale 隧道，SSH 进入 node1 强制提取数据库快照及 Weaviate 索引文件

#### 恢复指标
- **RTO (恢复时间目标)**: 若 node1 硬件损毁，系统必须支持在 **15 分钟** 内，通过备份在备用硬件上完成完整还原

### ✅ 合规性检查清单

- [ ] node0 纯净度检查: 确认 node0 上无 Docker 进程，无数据库容器运行
- [ ] 网络隔离检查: 确认 100.100.x.x 为唯一集群通信网段，且 Flannel 绑定在 tailscale0
- [ ] 持久化绑定检查: 确认所有 PVC 均位于 node1 本地路径
- [ ] 溢出测试: 模拟 node1 内存压测，验证 Soul Pod 是否正确溢出至 node0
- [ ] 备份完整性: 验证 Mac 终端能否成功通过 Tailscale 提取当日快照

### 📁 部署文件位置

- **部署清单**: `/Users/busiji/MyProject/xai-legion-manifests/`
- **存储配置**: `base/storage/postgres-pvc.yaml`, `weaviate-pvc.yaml`, `redis-pvc.yaml`
- **数据库部署**: `base/deployment/postgres-deployment.yaml`, `weaviate-deployment.yaml`, `redis-deployment.yaml`
- **ArgoCD 部署**: `base/deployment/argocd-deployment.yaml`
- **网络配置**: `base/network/k3s-network-config.yaml`
- **Soul 部署**: `base/deployment/soul-deployment.yaml` (已更新节点亲和性)

---

## GLM-4.7 API 配置

- **API Key**: ``
- **API 端点**: `https://open.bigmodel.cn/api/anthropic`
- **默认模型**: `zai/glm-5`

---

## 技能状态

### 已完成的部署文件 (Operation Nexus V4.1.2)
- ✅ 存储配置 (PostgreSQL, Weaviate, Redis PVC)
- ✅ 数据库部署 (PostgreSQL, Weaviate, Redis, ArgoCD)
- ✅ K3s 网络配置 (Flannel + Tailscale)
- ✅ Soul Deployment 节点亲和性更新

### 待完成的任务
- ⏳ ConfigMap (应用配置)
- ⏳ SealedSecrets (密钥管理)
- ⏳ ArgoCD Application (GitOps 配置)
- ⏳ 部署文档与 README

---

## MCP 服务配置规范 (2026-02-20)

### 📋 架构原则

**核心原则**：所有纯本地文件系统的桥接 MCP（@modelcontextprotocol/server-filesystem）都是**冗余**的，因为 OpenClaw 原生就拥有强大的 `read`, `write`, `edit` 等本地文件处理工具。

### 🎯 MCP 服务分类

#### ✅ 应该保留的服务（enabled: true）
- **云数据库**：Supabase, PostgreSQL 等需要外部 API 的服务
- **计算引擎**：QMD（语义搜索）等需要独立计算能力的服务
- **外部 API**：智谱联网检索等需要访问外部网络的服务
- **运维工具**：自动化运维脚本执行器

#### ❌ 应该禁用的服务（enabled: false）
- **本地文件系统桥接**：所有 `@modelcontextprotocol/server-filesystem` 类型的服务
  - 原因：原生工具（read/write/edit）功能更强大、更高效
  - 示例：gaokao-files, planning-with-files, jimibot-files, limebot-files, claw-docs

### 📝 Description 规范

所有 MCP 服务的 `description` 字段应遵循以下格式：

```json
"description": "【标签】简短描述。当触发条件时使用。"
```

**要素**：
1. **标签**：【xxx】 - 一目了然的分类标识
2. **简短描述**：服务的主要功能
3. **触发条件**：明确说明何时应该使用此服务

**示例**：
```json
"claw-docs": {
  "enabled": false,
  "description": "【冗余-已禁用】OpenClaw 系统说明书。请直接使用原生 read 工具访问 /Users/busiji/claw-docs。"
}

"qmd": {
  "enabled": true,
  "description": "【Markdown 知识库搜索】语义搜索工具。当指挥官需要搜索个人笔记、会议记录、文档内容时使用。"
}
```

### 📊 当前 MCP 服务状态 (2026-02-20)

| 服务名称 | 状态 | 类型 | 说明 |
|---------|------|------|------|
| chitin-core | ✅ enabled | 云数据库 | Supabase 备份库 |
| gaokao-project | ✅ enabled | 云数据库 | 高考项目生产数据库 |
| supabase-backup | ❌ disabled | 云数据库 | 备用数据库（未激活） |
| gaokao-files | ❌ disabled | 本地文件 | 冗余，使用原生工具 |
| planning-with-files | ❌ disabled | 本地文件 | 冗余，使用原生工具 |
| ops-tools | ✅ enabled | 运维工具 | 自动化脚本执行器 |
| qmd | ✅ enabled | 计算引擎 | Markdown 语义搜索 |
| zai-mcp-server | ✅ enabled | 外部 API | 智谱联网检索 |
| e2v-memory | ❌ disabled | 本地文件 | 旧版，已弃用 |
| jimibot-files | ❌ disabled | 本地文件 | 冗余，使用原生工具 |
| limebot-files | ❌ disabled | 本地文件 | 冗余，使用原生工具 |
| claw-docs | ❌ disabled | 本地文件 | 冗余，使用原生工具 |

### 🔧 重构经验总结

1. **识别冗余**：检查 MCP 服务是否提供原生工具已经具备的功能
2. **优化描述**：为所有服务添加标准化的 description，明确触发条件
3. **禁用冗余**：将本地文件系统桥接服务设置为 `enabled: false`
4. **记录变更**：将重构经验记录到 MEMORY.md，作为后续参考

---

## QMD 环境变量规范 (2026-02-21)

### 🔧 QMD_BLOCKED_COLLECTIONS

**用途**：设置 QMD MCP 服务的 collection 黑名单（被排除的不会检索）。

**格式**：逗号分隔的 collection 名称列表

**示例配置** (`mcporter.json`):
```json
"env": {
  "QMD_BLOCKED_COLLECTIONS": "myproject,claw-docs"
}
```

**行为说明**：
- 未设置或为空：允许访问所有 collections
- 设置后：黑名单中的 collections 会被排除，不在黑名单的都可以检索
- 影响范围：search, vsearch, query, status, resource (qmd://)

**当前配置**：
| Collection | 是否检索 | 说明 |
|------------|---------|------|
| passskills_main | ✅ 检索 | passkills 主目录 |
| daily-logs | ✅ 检索 | 日记 |
| workspace-memory | ✅ 检索 | 工作记忆 |
| myproject | ❌ 已排除 | Supabase SQL 文件 |
| claw-docs | ❌ 已排除 | OpenClaw 官方文档 |

**源码位置**：`/Users/busiji/passkills/mcp-hub/qmd/src/mcp.ts`

**修改记录**：
- 2026-02-21：添加 `QMD_BLOCKED_COLLECTIONS` 环境变量支持（黑名单模式）
- 修改函数：`isCollectionAllowed()`, `filterByAllowedCollections()`
- 影响工具：search, vsearch, query, status, resource handler

### 🧠 Molt 的肌肉记忆

当指挥官问"**qmd的黑名单**"时，直接回答当前黑名单配置：
```
QMD_BLOCKED_COLLECTIONS=myproject,claw-docs
```

---

## Cron 配置规范 (2026-02-20)

### ⏰ Heartbeat vs Cron

- **Heartbeat**：周期性轮询（如每 30 分钟），会漂移，用于批处理多个检查
- **Cron**：精准定时（如每天凌晨 4 点），可以设置 exact timing

### 📋 当前 Cron 任务

| 任务名称 | 调度时间 | 会话类型 | 说明 |
|---------|---------|---------|------|
| Daily Heartbeat - 4AM | 每天 04:00 (Asia/Shanghai) | main | 静默执行 HEARTBEAT.md 检查 |

### 🔧 配置文件

- **Heartbeat 配置**：`/Users/busiji/passkills/openclaw.json` → `agents.defaults.heartbeat`
  - `every: "0m"` - 禁用默认轮询
  - `target: "none"` - 强制静默模式

- **Cron 任务存储**：`/Users/busiji/passkills/cron/jobs.json`
