# OpenClaw 完整配置文档

> 镜像自官方文档: https://docs.openclaw.ai
> 版本: 2026.2.13 | 日期: 2026-02-16

---

## 文档索引

| 文档 | 大小 | 本地路径 | 官方链接 |
|------|------|----------|----------|
| **文档总索引** | 2.6KB | [OPENCLAW_DOCS_INDEX.md](./OPENCLAW_DOCS_INDEX.md) | - |
| **配置总览** | 6.6KB | [CONFIG_OVERVIEW.md](./CONFIG_OVERVIEW.md) | [官方](https://docs.openclaw.ai/gateway/configuration) |
| **配置参考** | 20KB | [CONFIG_REFERENCE.md](./CONFIG_REFERENCE.md) | [官方](https://docs.openclaw.ai/gateway/configuration-reference) |
| **配置示例** | 7.3KB | [CONFIG_EXAMPLES.md](./CONFIG_EXAMPLES.md) | [官方](https://docs.openclaw.ai/gateway/configuration-examples) |
| **多代理路由** | 9.6KB | [MULTI_AGENT.md](./MULTI_AGENT.md) | [官方](https://docs.openclaw.ai/concepts/multi-agent) |
| **救援机器人基线** | 13KB | [RESCUE_ROBOT_BASELINE.md](./RESCUE_ROBOT_BASELINE.md) | - |

**总计**: 约 59KB 完整文档

---

## 快速链接

### 官方文档

- **主页**: https://docs.openclaw.ai
- **文档索引 (LLM)**: https://docs.openclaw.ai/llms.txt
- **配置参考**: https://docs.openclaw.ai/gateway/configuration-reference
- **CLI 参考**: https://docs.openclaw.ai/cli

### 社区

- **GitHub**: https://github.com/openclaw/openclaw
- **Discord**: https://discord.com/invite/clawd
- **ClawHub (Skills)**: https://clawhub.com

---

## 配置文件位置

```
~/.openclaw/
├── openclaw.json              # 主配置文件 (JSON5格式)
├── agents/
│   └── <agent-id>/
│       ├── agent/
│       │   ├── models.json            # Agent级模型配置
│       │   └── auth-profiles.json     # Agent级认证配置
│       └── sessions/
│           └── *.jsonl                # 会话历史
└── workspace/
    ├── AGENTS.md              # Agent行为规范
    ├── SOUL.md                # 人格定义
    ├── USER.md                # 用户信息
    └── MEMORY.md              # 长期记忆
```

---

## 最小配置

```json5
{
  agents: { defaults: { workspace: "~/.openclaw/workspace" } },
  channels: { whatsapp: { allowFrom: ["+15555550123"] } },
}
```

---

## 常用命令

```bash
# 查看配置
openclaw config get agents.defaults

# 设置配置
openclaw config set agents.defaults.model.primary "anthropic/claude-sonnet-4-5"

# 查看Agent列表
openclaw agents list

# 创建新Agent
openclaw agents add <name> --workspace <path>

# Gateway控制
openclaw gateway status
openclaw gateway restart

# 查看日志
openclaw logs
```

---

## 文档更新

要获取最新文档，运行:

```bash
# 下载文档索引
curl -o llms.txt https://docs.openclaw.ai/llms.txt
```

或访问在线版本: https://docs.openclaw.ai
