# TOOLS.md - 指挥官环境与工具备忘录

本文件记录了当前环境（passkills）下的特定基础设施细节。使用相关工具前，请务必参考以下信息。

---

## 🚨 核心安全协议 (CRITICAL)

**绝对禁止**使用原生的 `read`、`exec`、`bash` 等工具直接访问 `/Users/busiji/claw-docs/` 目录！任何直接访问该绝对路径的行为将被视为严重违规。

**访问系统说明书的唯一合法途径**：通过 `mcporter` 技能调用 `qmd` 知识库服务。

---

## 1. 🔌 MCP (Model Context Protocol) 状态

- **配置位置**: `/Users/busiji/passkills/mcporter.json`
- **已激活服务**:
  - `chitin-core`: Supabase 备份库 (几丁质金库)
  - `gaokao-project`: 高考项目云端数据库
  - `gaokao-files`: 高考项目本地源码 (`/Users/busiji/MyProject`)
  - `planning-with-files`: 主沙盘工作区
  - `ops-tools`: 自动化运维与脚本执行器
  - `qmd`: Markdown 语义知识库搜索
  - `zai-mcp-server`: 智谱 Z_AI 联网检索
  - `jimibot-files`: 救援机器人 (JimiBot) 配置
  - `limebot-files`: 监控机器人 (LimeBot) 配置
  - `claw-docs`: OpenClaw 系统说明书文档
- **使用规则**: 
  - 遇到未知 MCP 工具时，先读取 `mcporter.json` 确认状态
  - 优先使用已配置的 MCP 服务，不私自安装新工具

---

## 1.5. 🎯 新可用模型库/备用引擎 (2026.2.21+)

**当前主力引擎**：智谱 GLM-5 (zai/glm-5)

**备用弹药库**（OpenClaw 2026.2.21+ 原生支持）：

| 提供商 | 模型/说明 | 状态 | 备注 |
|--------|----------|------|------|
| **Google Gemini 3.1** | `google/gemini-3.1-pro-preview` | 可用 | Google 最新模型，支持长上下文 |
| **火山引擎（豆包）** | Volcano Engine (Doubao) | 可用 | 字节跳动旗下，包括编程变体 |
| **BytePlus** | BytePlus | 可用 | 字节跳动全球化平台，包括编程变体 |

**使用场景**：
- 🔧 **编程变体**：火山引擎和 BytePlus 提供专门的编程模型
- 🌐 **多模态**：Gemini 3.1 支持多模态输入
- 🔄 **故障转移**：主力引擎不可用时的备选方案

**配置方式**（如需切换）：
- 更新 `openclaw.json` → `agents.defaults.model.primary`
- 或使用频道级模型覆盖 `channels.modelByChannel`

---

## 2. 🖥️ 服务器与网络 (SSH & Hosts)

- **主工作站**: 不死机的MacBook Pro (当前宿主机)
- **领地路径**: `/Users/busiji/passkills/`
- **远程节点**:
  - `node01` (47.111.21.195) - 计算补给站 (2GB RAM)
  - `node02` (116.62.168.71) - 主控/记忆中枢 (4GB RAM)
- **访问规则**: 仅在获得明确指令时访问远程节点

## 3. 🤖 双子星系统 (Gateway Cluster)

| 服务 | 端口 | 状态目录 | 职责 |
|------|------|----------|------|
| 主 Gateway | 18789 | `/Users/busiji/passkills` | 主控节点 |
| 监控机器人 (LimeBot) | 18818 | `/Users/busiji/LimeBot` | 日志监控 |
| 救援机器人 (JimiBot) | 18819 | `/Users/busiji/JimiBot` | 备用救援 |

- **日志挂载**: 
  - LimeBot 挂载 `/Users/busiji/passkills/logs` → `/monitored_logs`
  - LimeBot 挂载 `/Users/busiji/JimiBot/logs` → `/rescue_logs`

## 4. 🎙️ 语音与媒体偏好 (TTS Preferences)

- **系统播报**: 默认使用平静、专业的语气
- **讲故事/长文本**: 尝试使用更有表现力的语音配置

## 5. 🚫 工具使用禁忌 (Conventions)

- **绝不私装**: 严禁私自运行 `npm install -g`、`bun install -g` 等全局安装命令
- **先查后用**: 使用工具前，先检查 MCP 配置中是否已有可用服务
- **沙箱限制**: 如果 `exec` 工具报错"网络不可达"或"没有权限"，立即停止并向指挥官汇报
- **修改确认**: 在使用 `edit` 修改任何非 Markdown 文件前，必须先解释要修改的内容
- **删除谨慎**: 优先使用 `trash` 而非 `rm`，确保可恢复

#### 🔍 关于"QMD领地检索"的专属默契 (肌肉记忆)
- **底层原理**：QMD 知识库搜索服务是由底层的 `mcporter` 技能托管的 MCP 服务。
- **触发条件**：当指挥官（用户）在对话中提到"**使用 qmd**"、"**领地检索**"、"**搜一下我的笔记**"或类似的大白话时。
- **你的标准动作**：你必须立刻明白指挥官的意图，**不需要向指挥官确认，也不需要解释你正在使用 mcporter**。请直接在后台默默调用 `mcporter` 技能，桥接 `qmd` 服务执行语义搜索，然后直接把检索到的结果总结并汇报给指挥官。
--------------------------------------------------------------------------------

---

*更新记录：2026-02-20 - 根据系统说明书模板填写，添加 MCP 服务列表和双子星系统配置*
